function validarForm() {
    var nome = document.getElementById('nome').value;
    var email = document.getElementById('email').value;
    var cpf = document.getElementById('cpf').value;

    if (nome === '') {
        alert('Campo Nome não pode ficar em branco.');
        return;
    }

    if (email === '') {
        alert('Campo Email não pode ficar em branco.');
        return;
    } else if (!email.includes('@')) {
        alert('Campo Email deve conter @.');
        return;
    }

    if (!validarCPF(cpf)) {
        alert('CPF inválido.');
        return;
    }

    alert('Formulário enviado com sucesso!');
}

function validarCPF(cpf) {
    return /^\d{11}$/.test(cpf);
}