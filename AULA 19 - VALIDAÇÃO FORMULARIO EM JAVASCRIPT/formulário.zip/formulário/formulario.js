function valFor() {
    var nome = document.getElementById('nome').value;
    var email = document.getElementById('email').value;
    var cpf = document.getElementById('cpf').value;

    if (nome === '') {
        alert('O campo do nome não pode ficar em branco.');
        return;
    }

    if (email === '') {
        alert('O campo do Email não pode ficar em branco.');
        return;
    } 
    else if (!email.includes('@')) {
        alert('O campo do Email deve conter @.');
        return;
    }

    if (!validarCPF(cpf)) {
        alert('CPF inválido.');
        return;
    }

    alert('Formulário enviado com sucesso!');
}

function validarCPF(cpf) {
    return /^\d{11}$/.test(cpf);
}